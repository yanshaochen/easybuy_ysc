CREATE TRIGGER tri_auto_uuid
BEFORE INSERT ON easybuy_order
FOR EACH ROW
  BEGIN
if new.eo_id = '1' THEN set new.eo_id = (select uuid());
end if;
END;
